#!/bin/bash
#
# Licensed Materials - Property of IBM
# 5725A15, 5724R81
# (c) Copyright IBM Corp. 2010, 2017  All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
echo "=========================================="
echo "Begin downloadImages.sh"
date
if [[ $ScriptsDir = "" ]]; then
	source ./d_utils.sh
	echo $ScriptsDir
fi
start_time_2=$(date +%s)
filename=$ScriptsDir/"status.log"
function downloadImages_BMX() {
        echo "docker login start..."
        bx api https://api.ng.bluemix.net
        bx login --apikey $APIKEY
        if [ $? -eq 0  ] ;then
            echo "docker login successfully."
        else
            echo "docker authentication error."
            exit_script
        fi
        bx cr login
        docker pull $ARTIFACTORY_URL/$CPE_IMAGE_NAME:$CPE_IMAGE_TAG
        docker pull $ARTIFACTORY_URL/$ICN_IMAGE_NAME:$ICN_IMAGE_TAG
        docker pull $ARTIFACTORY_URL/$DB2_IMAGE_NAME:$DB2_IMAGE_TAG
        docker pull $ARTIFACTORY_URL/$LDAP_IMAGE_NAME:$LDAP_IMAGE_TAG
}

function downloadImages_IBMJDK() {
	jdk_version=$(docker image inspect $JDK_IMAGE_NAME:$JDK_IMAGE_TAG)
	if [ $? -ne 0 ]; then
		echo "Downloading IBM SDK container"
		docker logout
		if [[ $REGISTRY_USERNAME != "" ]] && [[ $REGISTRY_PASSWORD != "" ]]; then
			docker login -u $REGISTRY_USERNAME -p $REGISTRY_PASSWORD
		fi
		docker pull $JDK_IMAGE_NAME:$JDK_IMAGE_TAG  
	else
		echo "IBM SDK container already loaded....skipping download"
	fi
}

function downloadImages_Artifatory() {
        echo "docker login start..."
        docker login -u $REGISTRY_USERNAME -p $REGISTRY_PASSWORD 
         if [ $? -eq 0  ] ;then
            echo "login docker store successfully."
        else
            echo "docker authentication error."
            exit_script
        fi
        echo docker pull $DOCKER_REGISTRY_URL/$CPE_IMAGE_NAME:$CPE_IMAGE_TAG
        docker pull $DOCKER_REGISTRY_URL/$CPE_IMAGE_NAME:$CPE_IMAGE_TAG
        
        if [[ "Mac"x = "$OS"x ]]; then
        	 docker login -u $REGISTRY_USERNAME -p $REGISTRY_PASSWORD 
        fi
        echo docker pull $DOCKER_REGISTRY_URL/$ICN_IMAGE_NAME:$ICN_IMAGE_TAG
        docker pull $DOCKER_REGISTRY_URL/$ICN_IMAGE_NAME:$ICN_IMAGE_TAG 
        
        if [[ "Mac"x = "$OS"x ]]; then
        	 docker login -u $REGISTRY_USERNAME -p $REGISTRY_PASSWORD 
        fi
        echo docker pull $DOCKER_REGISTRY_URL/$DB2_IMAGE_NAME:$DB2_IMAGE_TAG 
        docker pull $DOCKER_REGISTRY_URL/$DB2_IMAGE_NAME:$DB2_IMAGE_TAG 

		if [[ "Mac"x = "$OS"x ]]; then
        	 docker login -u $REGISTRY_USERNAME -p $REGISTRY_PASSWORD 
        fi
        echo docker pull $DOCKER_REGISTRY_URL/$LDAP_IMAGE_NAME:$LDAP_IMAGE_TAG 
        docker pull $DOCKER_REGISTRY_URL/$LDAP_IMAGE_NAME:$LDAP_IMAGE_TAG 
}

if [[ $GET_IMAGE_FROM_BLUEMIX = "true" ]] || [[ $GET_IMAGE_FROM_BLUEMIX = "yes" ]]; then
	downloadImages_IBMJDK
	downloadImages_BMX
else
	downloadImages_IBMJDK
#	downloadImages_Artifatory
fi

end_time_2=$(date +%s)
duration_2=$((($end_time_2-$start_time_2)/60))
echo "Download IBM JDK docker image took $duration_2 minutes"

if [ $? -eq 0 ] ;then
    echo -e "\033[36mFinished downloading all the images successfully \033[0m"
	  sed -i.bak 's/downloadImages: NotCompleted/downloadImages: Completed/g' $filename
else
    exit_script
fi
echo "=========================================="
